import 'package:my_spoken_schedules/model/task_model.dart';

class TasksViewModel {
  final task_model? taskModel;

  TasksViewModel(this.taskModel);
}
