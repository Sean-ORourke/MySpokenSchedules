import 'package:my_spoken_schedules/model/task_model.dart';
import 'package:my_spoken_schedules/model/schedule_model.dart';

class SchedulesViewModel {
  final schedule_model? scheduleModel;

  SchedulesViewModel(this.scheduleModel);
}
