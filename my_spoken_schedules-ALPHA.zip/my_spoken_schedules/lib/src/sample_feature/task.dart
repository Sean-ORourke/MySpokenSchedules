/// A placeholder class that represents an entity or model.
class Task {
  const Task(this.id);

  final int id;
}
