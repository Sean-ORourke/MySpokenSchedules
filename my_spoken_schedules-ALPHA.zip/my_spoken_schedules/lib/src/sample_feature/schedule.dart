/// A placeholder class that represents an entity or model.
class Schedule {
  const Schedule(this.id);

  final int id;
}
