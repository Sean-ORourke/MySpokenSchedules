package com.example.my_spoken_schedules

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
